
import express from 'express';
import apiRoutes from './routes/apiRoutes.js';
import sequelize from './config/database.js';
import bodyParser from 'body-parser';
import https from 'https';
import http from 'http';
import fs from 'fs';
import path from 'path';
import dotenv from 'dotenv';
import requestIp from 'request-ip';
import cors from "cors"; // Importa el módulo 'cors'

dotenv.config(); // Carga las variables de entorno desde el archivo .env

const app = express();

// Configurar middleware de CORS para permitir solicitudes desde http://localhost:3001
// app.use(cors({ origin: "http://localhost:3004" }));
app.use(cors());
//app.use(cors({ origin: "http://38.25.40.91" }));

// Aumentar el límite de carga a 10mb (ajusta según lo necesario)
app.use(express.json({ limit: '2048mb' }));
app.use(express.urlencoded({ limit: '2048mb', extended: true }));

// Agrega el middleware para obtener la dirección IP pública
app.use(requestIp.mw());

// Middleware para manejar datos JSON y URL codificados
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Conexión a la base de datos
sequelize
  .authenticate()
  .then(() => {
    console.log('Conexión exitosa a la base de datos');
  })
  .catch(err => {
    console.error('Error en la conexión a la base de datos:', err);
  });

// Obtén la ruta de los archivos de certificado y clave
const certPath = path.join(path.dirname(new URL(import.meta.url).pathname), 'cert.pem');
const keyPath = path.join(path.dirname(new URL(import.meta.url).pathname), 'key.pem');

// Lee la contraseña de la clave privada desde un archivo o variable (reemplaza con tu propio método)
const privateKeyPassphrase = 'mishi25';

// Configura opciones del servidor HTTPS
const httpsOptions = {
  key: fs.readFileSync('key.pem', 'utf8'),
  cert: fs.readFileSync('cert.pem', 'utf8'),
  passphrase: privateKeyPassphrase,
};

// Rutas API
// Ruta global para todas las APIs: api/*
app.use('/api', apiRoutes);

// Crea un servidor HTTPS
//const server = https.createServer(httpsOptions, app);

// HTTP
const server = http.createServer(app);

// Manejo de errores
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).send('Algo salió mal en el servidor');
});

// Obtiene la URL o IP desde la variable de entorno
const serverUrl = process.env.SERVER_URL || 'https://localhost';

// Iniciar el servidor
const port = process.env.PORT || 3000;

app.use((req, res, next) => {
  const clientIp = req.clientIp;
  console.log(`Solicitud desde la dirección IP: ${clientIp}`);
  next();
});

process.on('SIGINT', () => {
  console.log('Saliendo de la aplicación...');
  // Realiza cualquier limpieza necesaria antes de salir
  process.exit();
});

server.listen(port, () => {
  console.log(`Servidor en ejecución en ${serverUrl}:${port}`);
});