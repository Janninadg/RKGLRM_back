import { Sequelize } from 'sequelize';
import config from './config.js';

const sequelize = new Sequelize(
  config.db.database,
  config.db.username,
  config.db.password,
  {
    host: config.db.host,
    dialect: 'mysql',
    define: {
      timestamps: false,
    },
    pool: {
      max: 10000,       // Número máximo de conexiones en el pool
      min: 0,        // Número mínimo de conexiones en el pool
      acquire: 8000, // Tiempo máximo en milisegundos para adquirir una conexión
      idle: 0,    // Tiempo máximo en milisegundos que una conexión puede estar inactiva
    },
    omitNull: true,
    logging: false, // Puedes desactivar el logging de Sequelize si no necesitas mensajes de log
    onEachQuery: async (query, sequelize) => {
      // Cerrar la conexión después de cada consulta
      await sequelize.connectionManager.close();
    },
  }
);

export default sequelize;